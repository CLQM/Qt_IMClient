#ifndef COMMON_H
#define COMMON_H
//==============信息总表============

#include "personinfo.h"
#include "registerinfo.h"
#include "ipaddrinfo.h"
#include "statuinfo.h"
//#include "imageinfo.h"

#include "userinfo.h"

//#include "groupinfo.h"
//#include "friendinfo.h"
//#include "privatechatrecord.h"

#endif // COMMON_H

